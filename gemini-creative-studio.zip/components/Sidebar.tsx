
import React from 'react';
import { Modality } from '../types';

interface SidebarProps {
  currentModality: Modality;
  setModality: (m: Modality) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentModality, setModality }) => {
  const menuItems = [
    { id: Modality.TEXT, icon: '💬', label: 'Chat' },
    { id: Modality.IMAGE, icon: '🎨', label: 'Images' },
    { id: Modality.VIDEO, icon: '🎥', label: 'Video' },
    { id: Modality.SPEECH, icon: '🎙️', label: 'Speech' },
  ];

  return (
    <div className="w-20 md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full transition-all">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white">G</div>
        <h1 className="hidden md:block font-bold text-xl tracking-tight">Studio</h1>
      </div>
      
      <nav className="flex-1 px-4 py-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setModality(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              currentModality === item.id 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            <span className="hidden md:block font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="hidden md:block p-4 bg-slate-800/50 rounded-xl">
          <p className="text-xs text-slate-500 uppercase font-semibold mb-2">Powering with</p>
          <p className="text-sm font-medium text-slate-300">Gemini 3 Flash</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
