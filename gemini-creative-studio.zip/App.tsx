
import React, { useState, useCallback, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import { Message, Modality, GenerationSettings } from './types';
import { generateText, generateImage, generateVideo, generateSpeech } from './services/geminiService';

const App: React.FC = () => {
  const [modality, setModality] = useState<Modality>(Modality.TEXT);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [settings, setSettings] = useState<GenerationSettings>({
    aspectRatio: '1:1',
    resolution: '720p',
    voice: 'Kore'
  });

  const checkVideoKey = async () => {
    // According to guidelines for Veo models
    if (typeof (window as any).aistudio?.hasSelectedApiKey === 'function') {
      const hasKey = await (window as any).aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio.openSelectKey();
      }
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!inputText.trim() || isGenerating) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputText,
      modality,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    const currentInput = inputText;
    setInputText('');
    setIsGenerating(true);

    const assistantMsgId = (Date.now() + 1).toString();
    const assistantMsg: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content: 'Starting generation...',
      modality,
      timestamp: Date.now(),
      isLoading: true
    };
    setMessages(prev => [...prev, assistantMsg]);

    try {
      if (modality === Modality.TEXT) {
        const history = messages.map(m => ({ 
          role: m.role === 'user' ? 'user' : 'model', 
          parts: [{ text: m.content }] 
        }));
        const response = await generateText(currentInput, history);
        updateAssistantMessage(assistantMsgId, response);
      } else if (modality === Modality.IMAGE) {
        const url = await generateImage(currentInput, settings);
        updateAssistantMessage(assistantMsgId, "Generated your image:", url);
      } else if (modality === Modality.VIDEO) {
        await checkVideoKey();
        const url = await generateVideo(currentInput, settings, (status) => {
          setMessages(prev => prev.map(m => m.id === assistantMsgId ? { ...m, content: status } : m));
        });
        updateAssistantMessage(assistantMsgId, "Your video is ready!", url);
      } else if (modality === Modality.SPEECH) {
        const base64 = await generateSpeech(currentInput, settings.voice);
        updateAssistantMessage(assistantMsgId, "Voice generated successfully.", base64);
      }
    } catch (err: any) {
      console.error(err);
      let errorMsg = "An error occurred during generation.";
      if (err.message?.includes("Requested entity was not found")) {
          // Reset key for Veo if error
          if (modality === Modality.VIDEO) {
             await (window as any).aistudio?.openSelectKey();
          }
      }
      updateAssistantMessage(assistantMsgId, `Error: ${err.message || errorMsg}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const updateAssistantMessage = (id: string, content: string, mediaUrl?: string) => {
    setMessages(prev => prev.map(m => 
      m.id === id ? { ...m, content, mediaUrl, isLoading: false } : m
    ));
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
      <Sidebar currentModality={modality} setModality={setModality} />
      
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-8 bg-slate-900/50 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <span className="text-xl">
              {modality === Modality.TEXT && '💬'}
              {modality === Modality.IMAGE && '🎨'}
              {modality === Modality.VIDEO && '🎥'}
              {modality === Modality.SPEECH && '🎙️'}
            </span>
            <h2 className="font-semibold text-lg">{modality} Studio</h2>
          </div>
          
          <div className="flex gap-4">
            {modality !== Modality.TEXT && (
              <select 
                className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={settings.aspectRatio}
                onChange={(e) => setSettings({ ...settings, aspectRatio: e.target.value as any })}
              >
                <option value="1:1">1:1 Square</option>
                <option value="16:9">16:9 Wide</option>
                <option value="9:16">9:16 Portrait</option>
                <option value="4:3">4:3 Standard</option>
              </select>
            )}
            {modality === Modality.SPEECH && (
              <select 
                className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={settings.voice}
                onChange={(e) => setSettings({ ...settings, voice: e.target.value })}
              >
                <option value="Kore">Kore (Neutral)</option>
                <option value="Puck">Puck (Cheerful)</option>
                <option value="Charon">Charon (Deep)</option>
                <option value="Fenrir">Fenrir (Strong)</option>
                <option value="Zephyr">Zephyr (Light)</option>
              </select>
            )}
          </div>
        </header>

        <ChatWindow messages={messages} />

        <div className="p-4 md:p-6 bg-slate-900/30 border-t border-slate-800">
          <form 
            onSubmit={handleSendMessage}
            className="max-w-4xl mx-auto relative group"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                modality === Modality.TEXT ? "Ask anything..." :
                modality === Modality.IMAGE ? "Describe an image to generate..." :
                modality === Modality.VIDEO ? "Describe a scene for a video..." :
                "Enter text to speak..."
              }
              className="w-full bg-slate-800 border border-slate-700 rounded-2xl px-6 py-4 pr-16 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-slate-100 placeholder-slate-500 shadow-xl"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isGenerating}
              className={`absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                inputText.trim() && !isGenerating 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' 
                  : 'bg-slate-700 text-slate-500 cursor-not-allowed'
              }`}
            >
              {isGenerating ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              )}
            </button>
          </form>
          <p className="text-center text-[10px] text-slate-600 mt-3 font-medium uppercase tracking-widest">
            Gemini Creative Studio • Powered by Google AI
          </p>
        </div>
      </main>
    </div>
  );
};

export default App;
