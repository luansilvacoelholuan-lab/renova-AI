
export enum Modality {
  TEXT = 'TEXT',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
  SPEECH = 'SPEECH'
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  modality: Modality;
  mediaUrl?: string;
  timestamp: number;
  isLoading?: boolean;
}

export interface GenerationSettings {
  aspectRatio: '1:1' | '3:4' | '4:3' | '9:16' | '16:9';
  resolution?: '720p' | '1080p';
  voice?: string;
}
